import json
import os

def handler(event, context):
    print(json.dumps({
        "event": event,
        "granules_queue_url": os.environ.get("GRANULES_QUEUE_URL"),
        "table_name": os.environ.get("TABLE_NAME"),
        "cumulus_ingest_queue_url": os.environ.get("CUMULUS_INGEST_QUEUE_URL"),
    }))

    return {
        "ok": True
    }
